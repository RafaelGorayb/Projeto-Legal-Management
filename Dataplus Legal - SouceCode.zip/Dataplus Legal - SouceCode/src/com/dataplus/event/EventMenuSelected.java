package com.dataplus.event;

public interface EventMenuSelected {

    public void selected(int index);
}
