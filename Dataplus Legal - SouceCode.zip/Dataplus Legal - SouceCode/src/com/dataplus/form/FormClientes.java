package com.dataplus.form;

import connection.connection;
import static com.dataplus.main.mainScreen.main;
import com.dataplus.model.modelCliente;
import com.dataplus.model.modelClienteDAO;
import com.dataplus.model.modelProcesso;
import com.dataplus.model.modelProcessoDAO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;

public class FormClientes extends javax.swing.JPanel {

    connection conexao = new connection();
    //variaveis para fazer a serach bar

    public FormClientes() {
        initComponents();
        setOpaque(false);
        jTableC.getTableHeader().setOpaque(false);
        jTableC.setRowHeight(40);
        readJTableC();
        readComboUF();
    }

    public static void readJTableC() {

        DefaultTableModel modelo = (DefaultTableModel) FormClientes.jTableC.getModel();
        modelo.setNumRows(0);
        modelClienteDAO dao = new modelClienteDAO();

        for (modelCliente c : dao.read()) {

            modelo.addRow(new Object[]{
                c.getIdcliente(),
                c.getNome(),
                c.getCidade(),
                c.getUf(),
                c.getLogradouro(),
                c.getEmail(),
                c.getTelefone(),
                c.getMedicamentos()
            });

        }

    }

    public static void readComboUF() {

        //DefaultComboBoxModel comboBoxModel = (DefaultComboBoxModel) comboUF.getModel();
        modelClienteDAO dao = new modelClienteDAO();
        comboUF.addItem("-");
        //comboUF.removeAllItems();

        for (modelCliente c : dao.readUF()) {
            comboUF.addItem(c.getUf());

        }

    }

    public static void searchUfCombo() {

        DefaultTableModel modelo = (DefaultTableModel) FormClientes.jTableC.getModel();
        modelo.setNumRows(0);
        modelClienteDAO dao = new modelClienteDAO();

        for (modelCliente c : dao.searchComboC()) {

            modelo.addRow(new Object[]{
                c.getIdcliente(),
                c.getNome(),
                c.getCidade(),
                c.getUf(),
                c.getLogradouro(),
                c.getEmail(),
                c.getTelefone(),
                c.getMedicamentos()
            });

        }

    }

    public static void searchJTableC() {

        DefaultTableModel modelo = (DefaultTableModel) FormClientes.jTableC.getModel();
        modelo.setNumRows(0);
        modelClienteDAO dao = new modelClienteDAO();

        for (modelCliente c : dao.search()) {

            modelo.addRow(new Object[]{
                c.getIdcliente(),
                c.getNome(),
                c.getCidade(),
                c.getUf(),
                c.getLogradouro(),
                c.getEmail(),
                c.getTelefone(),
                c.getMedicamentos()
            });

        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jList2 = new javax.swing.JList<>();
        jPanel1 = new javax.swing.JPanel();
        panelShadow1 = new com.dataplus.swing.PanelShadow();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableC = new javax.swing.JTable();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        comboUF = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        jList2.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });

        jPanel1.setBackground(new java.awt.Color(244, 246, 255));
        jPanel1.setOpaque(false);

        panelShadow1.setBackground(new java.awt.Color(255, 255, 255));
        panelShadow1.setShadowOpacity(0.1F);
        panelShadow1.setShadowSize(15);
        panelShadow1.setShadowType(com.dataplus.swing.ShadowType.BOT);

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jScrollPane1.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N

        jTableC.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 12)); // NOI18N
        jTableC.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "Cidade", "UF", "Logradouro", "E-mail", "telefone", "Medicamentos utilizados", "Como conheceu"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableC.setFocusable(false);
        jTableC.setGridColor(new java.awt.Color(204, 204, 204));
        jTableC.setOpaque(false);
        jTableC.setSelectionBackground(new java.awt.Color(153, 204, 255));
        jTableC.setShowGrid(true);
        jTableC.setShowVerticalLines(false);
        jTableC.getTableHeader().setReorderingAllowed(false);
        jTableC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableCMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableC);
        if (jTableC.getColumnModel().getColumnCount() > 0) {
            jTableC.getColumnModel().getColumn(1).setPreferredWidth(200);
        }

        jTextField1.setBackground(new java.awt.Color(204, 204, 204));
        jTextField1.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(51, 51, 51));
        jTextField1.setText("Digite um nome");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField1KeyReleased(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Pesquise aqui pelo nome:");

        comboUF.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboUFItemStateChanged(evt);
            }
        });
        comboUF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboUFActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("ou");

        jLabel3.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("UF:");

        javax.swing.GroupLayout panelShadow1Layout = new javax.swing.GroupLayout(panelShadow1);
        panelShadow1.setLayout(panelShadow1Layout);
        panelShadow1Layout.setHorizontalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(panelShadow1Layout.createSequentialGroup()
                        .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField1)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(comboUF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 602, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50))
        );
        panelShadow1Layout.setVerticalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboUF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(50, 50, 50)
                .addComponent(jScrollPane1)
                .addGap(68, 68, 68))
        );

        jButton3.setText("inserir");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton2.setText("Deletar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(panelShadow1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(30, 30, 30))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(jButton3)
                .addGap(26, 26, 26)
                .addComponent(jButton2)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(panelShadow1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(54, 54, 54))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        main.removeAll();
        main.add(new FormEditarClientes());
        main.repaint();
        main.revalidate();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTableCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableCMouseClicked

        if (evt.getClickCount() == 2) {

            main.removeAll();
            main.add(new FormEditarClientes());
            main.repaint();
            main.revalidate();

            FormEditarClientes.txtNome.setText((String) jTableC.getValueAt(jTableC.getSelectedRow(), 1));
            FormEditarClientes.txtCidade.setText((String) jTableC.getValueAt(jTableC.getSelectedRow(), 2));
            FormEditarClientes.txtUF.setText((String) jTableC.getValueAt(jTableC.getSelectedRow(), 3));
            FormEditarClientes.txtLogradouro.setText((String) jTableC.getValueAt(jTableC.getSelectedRow(), 4));
            FormEditarClientes.txtEmail.setText((String) jTableC.getValueAt(jTableC.getSelectedRow(), 5));
            FormEditarClientes.txtTelefone.setText((String) jTableC.getValueAt(jTableC.getSelectedRow(), 6));
            FormEditarClientes.txtMedicamentos.setText((String) jTableC.getValueAt(jTableC.getSelectedRow(), 7));

            FormEditarClientes.jButton1.setEnabled(false);

        }


    }//GEN-LAST:event_jTableCMouseClicked

    private void jTextField1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyReleased
        searchJTableC();
    }//GEN-LAST:event_jTextField1KeyReleased

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        modelCliente c = new modelCliente();
        modelClienteDAO dao = new modelClienteDAO();

        c.setIdcliente((int) jTableC.getValueAt(jTableC.getSelectedRow(), 0));
        dao.delete(c);
        readJTableC();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void comboUFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboUFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboUFActionPerformed

    private void comboUFItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboUFItemStateChanged
        searchUfCombo();
    }//GEN-LAST:event_comboUFItemStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JComboBox<String> comboUF;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JList<String> jList2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTableC;
    public static javax.swing.JTextField jTextField1;
    private com.dataplus.swing.PanelShadow panelShadow1;
    // End of variables declaration//GEN-END:variables
}
