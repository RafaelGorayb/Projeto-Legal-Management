package com.dataplus.form;

import static com.dataplus.main.mainScreen.main;
import com.dataplus.model.modelContrato;
import com.dataplus.model.modelContratoDAO;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author rafaelcorrea
 */
public class FormContratos extends javax.swing.JPanel {

    /**
     * Creates new form FormContratos
     */
    public FormContratos() {
        initComponents();
        readJTableCT();

    }

    public static void readJTableCT() {

        DefaultTableModel modelo = (DefaultTableModel) FormContratos.jTableCt.getModel();
        modelo.setNumRows(0);
        modelContratoDAO dao = new modelContratoDAO();

        for (modelContrato ct : dao.read()) {

            String ano = ct.getData().substring(0, 4);
            String mes = ct.getData().substring(5, 7);
            String dia = ct.getData().substring(8, 10);

            String data = dia + "/" + mes + "/" + ano;

            modelo.addRow(new Object[]{
                ct.getIdcontrato(),
                ct.getNomeCliente(),
                data,
                ct.getValor(),
                ct.getMetodoPagamento(),
                ct.getParcelas(),
                ct.getObservacoes()
            });

        }

    }
    
        public static void searchJTableCt() {

        DefaultTableModel modelo = (DefaultTableModel) FormContratos.jTableCt.getModel();
        modelo.setNumRows(0);
        modelContratoDAO dao = new modelContratoDAO();

        for (modelContrato ct : dao.searchCt()) {

            String ano = ct.getData().substring(0, 4);
            String mes = ct.getData().substring(5, 7);
            String dia = ct.getData().substring(8, 10);

            String data = dia + "/" + mes + "/" + ano;

            modelo.addRow(new Object[]{
                ct.getIdcontrato(),
                ct.getNomeCliente(),
                data,
                ct.getValor(),
                ct.getMetodoPagamento(),
                ct.getParcelas(),
                ct.getObservacoes()
            });

        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        panelShadow1 = new com.dataplus.swing.PanelShadow();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableCt = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtPesquisaContrato = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(244, 246, 255));

        panelShadow1.setBackground(new java.awt.Color(255, 255, 255));
        panelShadow1.setShadowOpacity(0.1F);
        panelShadow1.setShadowSize(15);
        panelShadow1.setShadowType(com.dataplus.swing.ShadowType.BOT);

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));

        jTableCt.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 12)); // NOI18N
        jTableCt.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Cliente", "Data", "Valor", "Método Pagamento", "parcelas", "observacoes"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableCt.setFocusable(false);
        jTableCt.setGridColor(new java.awt.Color(204, 204, 204));
        jTableCt.setRowHeight(40);
        jTableCt.setSelectionBackground(new java.awt.Color(153, 204, 255));
        jTableCt.setSelectionForeground(new java.awt.Color(51, 51, 51));
        jTableCt.setShowGrid(true);
        jTableCt.setShowVerticalLines(false);
        jTableCt.getTableHeader().setReorderingAllowed(false);
        jTableCt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableCtMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableCt);

        jLabel1.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Pesquise pelo cliente");

        txtPesquisaContrato.setBackground(new java.awt.Color(204, 204, 204));
        txtPesquisaContrato.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        txtPesquisaContrato.setForeground(new java.awt.Color(51, 51, 51));
        txtPesquisaContrato.setText("Digite aqui");
        txtPesquisaContrato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesquisaContratoActionPerformed(evt);
            }
        });
        txtPesquisaContrato.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPesquisaContratoKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout panelShadow1Layout = new javax.swing.GroupLayout(panelShadow1);
        panelShadow1.setLayout(panelShadow1Layout);
        panelShadow1Layout.setHorizontalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelShadow1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 858, Short.MAX_VALUE)
                        .addGap(50, 50, 50))
                    .addGroup(panelShadow1Layout.createSequentialGroup()
                        .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPesquisaContrato, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        panelShadow1Layout.setVerticalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtPesquisaContrato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 314, Short.MAX_VALUE)
                .addGap(66, 66, 66))
        );

        jButton1.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jButton1.setText("inserir");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jButton2.setText("Deletar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelShadow1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(panelShadow1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(34, 34, 34))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        modelContrato ct = new modelContrato();
        modelContratoDAO dao = new modelContratoDAO();

        ct.setIdcontrato((int) jTableCt.getValueAt(jTableCt.getSelectedRow(), 0));
        dao.delete(ct);
        readJTableCT();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        main.removeAll();
        main.add(new FormEditarContratos());
        main.repaint();
        main.revalidate();
        jButton1.setVisible(true);
        FormEditarContratos.jButton1.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtPesquisaContratoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesquisaContratoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesquisaContratoActionPerformed

    private void txtPesquisaContratoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPesquisaContratoKeyReleased
        searchJTableCt();
    }//GEN-LAST:event_txtPesquisaContratoKeyReleased

    private void jTableCtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableCtMouseClicked
        if (evt.getClickCount() == 2) {

            main.removeAll();
            main.add(new FormEditarContratos());
            main.repaint();
            main.revalidate();

            FormEditarContratos.txtCliente.setText((String) jTableCt.getValueAt(jTableCt.getSelectedRow(), 1));
            FormEditarContratos.txtData.setText((String) jTableCt.getValueAt(jTableCt.getSelectedRow(), 2));
            FormEditarContratos.txtValor.setText(String.valueOf(jTableCt.getValueAt(jTableCt.getSelectedRow(), 3)));
            FormEditarContratos.txtMetodoPag.setSelectedItem((String) jTableCt.getValueAt(jTableCt.getSelectedRow(), 4));
            FormEditarContratos.txtParcela.setSelectedItem(String.valueOf(jTableCt.getValueAt(jTableCt.getSelectedRow(), 5)));
            FormEditarContratos.txtObservacoes.setText((String) jTableCt.getValueAt(jTableCt.getSelectedRow(), 6));

            FormEditarContratos.jButton1.setVisible(false);

        }
    }//GEN-LAST:event_jTableCtMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTableCt;
    private com.dataplus.swing.PanelShadow panelShadow1;
    public static javax.swing.JTextField txtPesquisaContrato;
    // End of variables declaration//GEN-END:variables
}
