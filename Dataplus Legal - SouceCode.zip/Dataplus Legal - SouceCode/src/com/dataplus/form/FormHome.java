package com.dataplus.form;

import com.dataplus.model.modelCalendario;
import com.dataplus.model.modelCalendarioDAO;
import connection.connection;
import com.mindfusion.common.DateTime;
import com.mindfusion.common.DayOfWeek;
import com.mindfusion.drawing.SolidBrush;
import com.mindfusion.scheduling.Calendar;
import com.mindfusion.scheduling.DateStyle;
import com.mindfusion.scheduling.DayOfWeekStyle;
import com.mindfusion.scheduling.ThemeType;
import com.mindfusion.scheduling.model.Appointment;
import com.mindfusion.scheduling.model.Style;
import com.raven.chart.ModelChart;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FormHome extends javax.swing.JPanel {

    public String _dataFile;
    public Calendar calendar;
    public Color ItemBackground1;
    private static final long serialVersionUID = 1L;

    public FormHome() {
        initComponents();
        setOpaque(false);
        initGraphics();
        readCalendar();
        NumberOfRowsData();
        jScrollPane1.getVerticalScrollBar().setUnitIncrement(16);
        jScrollPane1.getHorizontalScrollBar().setUnitIncrement(16);

    }

    private void NumberOfRowsData() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.prepareStatement("select (select count(*) from cliente) as clienteRows,\n"
                                + "		(select count(*) from contrato) as contratoRows,\n"
                                + "		(select count(*) from processo) as processoRows,\n"
                                + "		(SELECT sum(valor) from contrato \n"
                                + "			WHERE MONTH(data) = MONTH(CURRENT_DATE())\n"
                                + "			AND YEAR(data) = YEAR(CURRENT_DATE())) as contratosMesAtual");
            rs = stmt.executeQuery();
            DecimalFormat formatter = new DecimalFormat("R$ ###,###,##0.00");
            while (rs.next()) {
                totalClientes.setText(String.valueOf(rs.getInt("clienteRows")));
                totalContratos.setText(String.valueOf(rs.getInt("contratoRows")));
                totalProcessos.setText(String.valueOf(rs.getInt("processoRows")));
                txtValorTotalContratos.setText(formatter.format(Double.parseDouble(String.valueOf(rs.getInt("contratosMesAtual")))));
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormHome.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void readCalendar() {
        //criar calendario
        calendar = new Calendar();
        calendar.setTheme(ThemeType.Light);

        //personalizar cor dos eventos
        Style personalEvents = new Style();
        personalEvents.setTextColor(new Color(102, 102, 102));
        personalEvents.setBrush(new SolidBrush(new Color(240, 196, 0)));
        personalEvents.setHeaderTextColor(new Color(102, 102, 102));
        calendar.getItemSettings().setStyle(personalEvents);

        //personalizar cor dos eventos quando clicado
        Style personalEventsLight = new Style();
        personalEventsLight.setBrush(new SolidBrush(new Color(219, 207, 151)));
        calendar.getItemSettings().setSelectedItemStyle(personalEventsLight);

        //pintar sabados e domingos de cinza claro
        DayOfWeekStyle style1 = new DayOfWeekStyle();
        style1.setDayOfWeek(DayOfWeek.Saturday);
        style1.getStyle().setBrush(new SolidBrush(new Color(245, 245, 245)));
        calendar.getDayOfWeekStyles().add(style1);
        style1 = new DayOfWeekStyle();
        style1.setDayOfWeek(DayOfWeek.Sunday);
        style1.getStyle().setBrush(new SolidBrush(new Color(245, 245, 245)));
        calendar.getDayOfWeekStyles().add(style1);

        //marcar dia atual
        DateStyle style = new DateStyle();
        style.setFrom(DateTime.now());
        style.setTo(DateTime.now());
        style.getStyle().setBrush(new SolidBrush(new Color(255, 238, 163)));
        calendar.getDayStyles().add(style);

        //adicionar calendario ao jpanel
        jPanel1.add(calendar);

        //adicionar os dados ao calendario
        modelCalendarioDAO cdao = new modelCalendarioDAO();

        for (modelCalendario ca : cdao.read()) {

            try {
                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                Date data1 = formato.parse(ca.getData());

                Appointment app = new Appointment();
                app.setHeaderText(ca.getDescricao());
                app.setStartTime(new DateTime(data1));
                app.setEndTime(new DateTime(data1));
                calendar.getSchedule().getItems().add(app);

            } catch (ParseException ex) {
                Logger.getLogger(FormHome.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    private void initGraphics() {

        //SELECT sum(valor), monthname(data) FROM contrato WHERE data > curdate() - interval (dayofmonth(curdate()) - 1) day - interval 6 month GROUP BY monthname(data)
        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.prepareStatement("SELECT sum(valor), monthname(data) FROM contrato WHERE data > curdate() - interval (dayofmonth(curdate()) - 1) day - interval 6 month GROUP BY monthname(data)");
            rs = stmt.executeQuery();
            chart1.addLegend("Receita " + Year.now().getValue(), new Color(0, 0, 0), Color.BLACK);
            while (rs.next()) {
                chart1.addData(new ModelChart(rs.getString("monthname(data)"), new double[]{rs.getInt("sum(valor)")}));
            }

            chart1.start();;
        } catch (SQLException ex) {
            Logger.getLogger(FormHome.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        panelShadow5 = new com.dataplus.swing.PanelShadow();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        totalContratos = new javax.swing.JLabel();
        panelShadow2 = new com.dataplus.swing.PanelShadow();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        totalClientes = new javax.swing.JLabel();
        panelShadow6 = new com.dataplus.swing.PanelShadow();
        jLabel9 = new javax.swing.JLabel();
        totalProcessos = new javax.swing.JLabel();
        panelShadow3 = new com.dataplus.swing.PanelShadow();
        jPanel1 = new javax.swing.JPanel();
        chart1 = new com.raven.chart.Chart();
        jLabel1 = new javax.swing.JLabel();
        txtValorTotalContratos = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();

        jTextField1.setText("jTextField1");

        jScrollPane1.setBorder(null);
        jScrollPane1.setOpaque(false);

        jPanel2.setBackground(new java.awt.Color(245, 245, 253));

        panelShadow5.setBackground(new java.awt.Color(255, 255, 255));
        panelShadow5.setShadowOpacity(0.1F);
        panelShadow5.setShadowSize(15);
        panelShadow5.setShadowType(com.dataplus.swing.ShadowType.BOT);

        jLabel6.setBackground(new java.awt.Color(51, 51, 51));
        jLabel6.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Novos contratos fechados ");
        jLabel6.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        jLabel7.setBackground(new java.awt.Color(51, 51, 51));
        jLabel7.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("este mes.");
        jLabel7.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        totalContratos.setBackground(new java.awt.Color(51, 51, 51));
        totalContratos.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 36)); // NOI18N
        totalContratos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        totalContratos.setText("10");

        javax.swing.GroupLayout panelShadow5Layout = new javax.swing.GroupLayout(panelShadow5);
        panelShadow5.setLayout(panelShadow5Layout);
        panelShadow5Layout.setHorizontalGroup(
            panelShadow5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelShadow5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(panelShadow5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelShadow5Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(totalContratos, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelShadow5Layout.setVerticalGroup(
            panelShadow5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow5Layout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel7)
                .addContainerGap(63, Short.MAX_VALUE))
            .addGroup(panelShadow5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelShadow5Layout.createSequentialGroup()
                    .addGap(42, 42, 42)
                    .addComponent(totalContratos, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(101, Short.MAX_VALUE)))
        );

        panelShadow2.setBackground(new java.awt.Color(255, 255, 255));
        panelShadow2.setShadowOpacity(0.1F);
        panelShadow2.setShadowSize(15);
        panelShadow2.setShadowType(com.dataplus.swing.ShadowType.BOT);

        jLabel3.setBackground(new java.awt.Color(51, 51, 51));
        jLabel3.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Novos clientes conquistados ");
        jLabel3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        jLabel4.setBackground(new java.awt.Color(51, 51, 51));
        jLabel4.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("este mes.");
        jLabel4.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        totalClientes.setBackground(new java.awt.Color(51, 51, 51));
        totalClientes.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 36)); // NOI18N
        totalClientes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        totalClientes.setText("10");

        javax.swing.GroupLayout panelShadow2Layout = new javax.swing.GroupLayout(panelShadow2);
        panelShadow2.setLayout(panelShadow2Layout);
        panelShadow2Layout.setHorizontalGroup(
            panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelShadow2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(totalClientes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelShadow2Layout.setVerticalGroup(
            panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow2Layout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel4)
                .addContainerGap(63, Short.MAX_VALUE))
            .addGroup(panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelShadow2Layout.createSequentialGroup()
                    .addGap(42, 42, 42)
                    .addComponent(totalClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(89, Short.MAX_VALUE)))
        );

        panelShadow6.setBackground(new java.awt.Color(255, 255, 255));
        panelShadow6.setShadowOpacity(0.1F);
        panelShadow6.setShadowSize(15);
        panelShadow6.setShadowType(com.dataplus.swing.ShadowType.BOT);

        jLabel9.setBackground(new java.awt.Color(51, 51, 51));
        jLabel9.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Processos em andamento.");
        jLabel9.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        totalProcessos.setBackground(new java.awt.Color(51, 51, 51));
        totalProcessos.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 36)); // NOI18N
        totalProcessos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        totalProcessos.setText("10");

        javax.swing.GroupLayout panelShadow6Layout = new javax.swing.GroupLayout(panelShadow6);
        panelShadow6.setLayout(panelShadow6Layout);
        panelShadow6Layout.setHorizontalGroup(
            panelShadow6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelShadow6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelShadow6Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(totalProcessos, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelShadow6Layout.setVerticalGroup(
            panelShadow6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow6Layout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(79, Short.MAX_VALUE))
            .addGroup(panelShadow6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelShadow6Layout.createSequentialGroup()
                    .addGap(42, 42, 42)
                    .addComponent(totalProcessos, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(101, Short.MAX_VALUE)))
        );

        panelShadow3.setBackground(new java.awt.Color(255, 255, 255));
        panelShadow3.setShadowOpacity(0.1F);
        panelShadow3.setShadowSize(15);
        panelShadow3.setShadowType(com.dataplus.swing.ShadowType.BOT);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout panelShadow3Layout = new javax.swing.GroupLayout(panelShadow3);
        panelShadow3.setLayout(panelShadow3Layout);
        panelShadow3Layout.setHorizontalGroup(
            panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 681, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        panelShadow3Layout.setVerticalGroup(
            panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                .addGap(39, 39, 39))
        );

        jLabel1.setFont(new java.awt.Font(".AppleSystemUIFont", 1, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Valor dos contratos no mes atual:");

        txtValorTotalContratos.setFont(new java.awt.Font(".AppleSystemUIFont", 1, 24)); // NOI18N
        txtValorTotalContratos.setForeground(new java.awt.Color(51, 51, 51));
        txtValorTotalContratos.setText("R$ 53.000,00");

        jLabel2.setFont(new java.awt.Font(".AppleSystemUIFont", 1, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel2.setText("Data:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "6 meses", "Ano inteiro" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(panelShadow3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(chart1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 703, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1)
                            .addComponent(txtValorTotalContratos))))
                .addGap(108, 108, 108)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelShadow2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelShadow6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelShadow5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(panelShadow5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelShadow2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(panelShadow3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtValorTotalContratos)))
                .addGap(8, 8, 8)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(chart1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelShadow6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(86, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.chart.Chart chart1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private com.dataplus.swing.PanelShadow panelShadow2;
    private com.dataplus.swing.PanelShadow panelShadow3;
    private com.dataplus.swing.PanelShadow panelShadow5;
    private com.dataplus.swing.PanelShadow panelShadow6;
    private javax.swing.JLabel totalClientes;
    private javax.swing.JLabel totalContratos;
    private javax.swing.JLabel totalProcessos;
    private javax.swing.JLabel txtValorTotalContratos;
    // End of variables declaration//GEN-END:variables
}
