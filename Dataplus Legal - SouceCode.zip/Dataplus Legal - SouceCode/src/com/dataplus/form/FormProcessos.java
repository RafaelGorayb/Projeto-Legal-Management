/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.dataplus.form;

import static com.dataplus.form.FormEditarProcessos.txtProcesso;
import static com.dataplus.main.mainScreen.main;
import com.dataplus.model.modelCalendario;
import com.dataplus.model.modelCalendarioDAO;
import com.dataplus.model.modelClienteDAO;

import com.dataplus.model.modelProcesso;
import com.dataplus.model.modelProcessoDAO;
import connection.connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author rafaelcorrea
 */
public class FormProcessos extends javax.swing.JPanel {

    /**
     * Creates new form FormProcessos
     */
    public FormProcessos() {
        initComponents();
        readJTableP();
    }

    public static void readJTableP() {

        DefaultTableModel modelo = (DefaultTableModel) FormProcessos.jTableP.getModel();
        modelo.setNumRows(0);
        modelProcessoDAO dao = new modelProcessoDAO();

        for (modelProcesso p : dao.read()) {

            modelo.addRow(new Object[]{
                p.getIdprocesso(),
                p.getAutor(),
                p.getReu(),
                p.getStatus(),
                p.getResponsavel(),
                p.getJusticaGratuita(),
                p.getDanosMorais(),
                p.getValorCausa(),
                p.getObservacoes()
            });

        }

    }

    public static void searchjTablePField() {

        DefaultTableModel modelo = (DefaultTableModel) FormProcessos.jTableP.getModel();
        modelo.setNumRows(0);
        modelProcessoDAO dao = new modelProcessoDAO();

        for (modelProcesso p : dao.searchField()) {

            modelo.addRow(new Object[]{
                p.getIdprocesso(),
                p.getAutor(),
                p.getReu(),
                p.getStatus(),
                p.getResponsavel(),
                p.getJusticaGratuita(),
                p.getDanosMorais(),
                p.getValorCausa()
            });

        }

    }

    public static void searchjTablePBox() {

        DefaultTableModel modelo = (DefaultTableModel) FormProcessos.jTableP.getModel();
        modelo.setNumRows(0);
        modelProcessoDAO dao = new modelProcessoDAO();

        for (modelProcesso p : dao.searchCombo()) {

            modelo.addRow(new Object[]{
                p.getIdprocesso(),
                p.getAutor(),
                p.getReu(),
                p.getStatus(),
                p.getResponsavel(),
                p.getJusticaGratuita(),
                p.getDanosMorais(),
                p.getValorCausa()
            });

        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        panelShadow1 = new com.dataplus.swing.PanelShadow();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableP = new javax.swing.JTable();
        txtPesquisaProcesso = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        boxResponsavel = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        boxResponsavel1 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(244, 246, 255));

        panelShadow1.setBackground(new java.awt.Color(255, 255, 255));
        panelShadow1.setShadowOpacity(0.1F);
        panelShadow1.setShadowSize(15);
        panelShadow1.setShadowType(com.dataplus.swing.ShadowType.BOT);

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));

        jTableP.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 12)); // NOI18N
        jTableP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nº Processo:", "Autor", "Réu", "Status", "Responsavel", "Justica gratuita", "Danos Morais", "Valor da causa", "observacoes"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableP.setFocusable(false);
        jTableP.setGridColor(new java.awt.Color(204, 204, 204));
        jTableP.setRowHeight(40);
        jTableP.setSelectionBackground(new java.awt.Color(153, 204, 255));
        jTableP.setShowGrid(true);
        jTableP.setShowVerticalLines(false);
        jTableP.getTableHeader().setReorderingAllowed(false);
        jTableP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableP);

        txtPesquisaProcesso.setBackground(new java.awt.Color(204, 204, 204));
        txtPesquisaProcesso.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        txtPesquisaProcesso.setForeground(new java.awt.Color(51, 51, 51));
        txtPesquisaProcesso.setText("Digite aqui");
        txtPesquisaProcesso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesquisaProcessoActionPerformed(evt);
            }
        });
        txtPesquisaProcesso.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPesquisaProcessoKeyReleased(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Pesquise pelo Nº Processo:");

        boxResponsavel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "Isabelle", "Pedro", "Rafael" }));
        boxResponsavel.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                boxResponsavelItemStateChanged(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("Responsável");

        jLabel2.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("ou");

        jLabel4.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Situacão");

        boxResponsavel1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "Formalização", "Contato com secretaria/plano saude", "Contato com o medico", "Pedido administrativo", "Coleta de documentos pessoais", "Elaboração da petição inicial", "Protocolo judicial", "Acompanhamento do processo", "Réplica", "Agravo de instrumento", "contestacao", "Contrarrazões", "Transito em julgado", "Caso suspenso", "Concluido" }));
        boxResponsavel1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                boxResponsavel1ItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout panelShadow1Layout = new javax.swing.GroupLayout(panelShadow1);
        panelShadow1.setLayout(panelShadow1Layout);
        panelShadow1Layout.setHorizontalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelShadow1Layout.createSequentialGroup()
                        .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtPesquisaProcesso)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(boxResponsavel, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(boxResponsavel1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelShadow1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 769, Short.MAX_VALUE)
                        .addGap(50, 50, 50))))
        );
        panelShadow1Layout.setVerticalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelShadow1Layout.createSequentialGroup()
                        .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPesquisaProcesso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(boxResponsavel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)))
                    .addGroup(panelShadow1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(boxResponsavel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 401, Short.MAX_VALUE)
                .addGap(68, 68, 68))
        );

        jButton1.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jButton1.setText("Inserir");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font(".AppleSystemUIFont", 0, 13)); // NOI18N
        jButton2.setText("Deletar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(panelShadow1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(panelShadow1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(72, 72, 72))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        main.removeAll();
        main.add(new FormEditarProcessos());
        main.repaint();
        main.revalidate();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        modelProcesso p = new modelProcesso();
        modelProcessoDAO dao = new modelProcessoDAO();

        modelCalendario ca = new modelCalendario();
        modelCalendarioDAO cdao = new modelCalendarioDAO();

        p.setIdprocesso((int) jTableP.getValueAt(jTableP.getSelectedRow(), 0));
        ca.setIdData((int) jTableP.getValueAt(jTableP.getSelectedRow(), 0));

        dao.delete(p);
        cdao.delete(ca);
        readJTableP();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTablePMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePMouseClicked
        if (evt.getClickCount() == 2) {

            modelCalendario ca = new modelCalendario();
            modelCalendarioDAO cdao = new modelCalendarioDAO();

            main.removeAll();
            main.add(new FormEditarProcessos());
            main.repaint();
            main.revalidate();

            FormEditarProcessos.txtProcesso.setText(String.valueOf(jTableP.getValueAt(jTableP.getSelectedRow(), 0)));
            FormEditarProcessos.txtAutor.setText((String) jTableP.getValueAt(jTableP.getSelectedRow(), 1));
            FormEditarProcessos.txtReu.setText((String) jTableP.getValueAt(jTableP.getSelectedRow(), 2));
            FormEditarProcessos.txtStatus.setSelectedItem((String) jTableP.getValueAt(jTableP.getSelectedRow(), 3));
            FormEditarProcessos.txtResponsavel.setSelectedItem((String) jTableP.getValueAt(jTableP.getSelectedRow(), 4));
            FormEditarProcessos.txtJustica.setSelectedItem((String) jTableP.getValueAt(jTableP.getSelectedRow(), 5));
            FormEditarProcessos.txtDanos.setSelectedItem((String) jTableP.getValueAt(jTableP.getSelectedRow(), 6));
            FormEditarProcessos.txtValorCausa.setText(String.valueOf(jTableP.getValueAt(jTableP.getSelectedRow(), 7)));
            FormEditarProcessos.txtobservacoes.setText(String.valueOf(jTableP.getValueAt(jTableP.getSelectedRow(), 8)));

            FormEditarProcessos.jButton8.setVisible(false);

            //ca.setIdData(Integer.parseInt(FormEditarProcessos.txtProcesso.getText()));
            //FormEditarProcessos.readJTablePrazo();
            Connection con = connection.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            DefaultTableModel modelo = (DefaultTableModel) FormEditarProcessos.jTablePrazo.getModel();

            try {
                stmt = con.prepareStatement("SELECT * FROM calendario WHERE iddata = ?");
                stmt.setInt(1, Integer.parseInt(txtProcesso.getText()));
                rs = stmt.executeQuery();

                while (rs.next()) {

                    String ano = rs.getString(3).substring(0, 4);
                    String mes = rs.getString(3).substring(5, 7);
                    String dia = rs.getString(3).substring(8, 10);

                    String data = dia + "/" + mes + "/" + ano;

                    modelo.addRow(new Object[]{
                        data,
                        rs.getString(4)
                    });

                }

            } catch (SQLException ex) {
                Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                connection.closeConnection(con, stmt, rs);
            }

        }
    }//GEN-LAST:event_jTablePMouseClicked

    private void txtPesquisaProcessoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesquisaProcessoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesquisaProcessoActionPerformed

    private void txtPesquisaProcessoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPesquisaProcessoKeyReleased
        searchjTablePField();
    }//GEN-LAST:event_txtPesquisaProcessoKeyReleased

    private void boxResponsavelItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_boxResponsavelItemStateChanged
        searchjTablePBox();
    }//GEN-LAST:event_boxResponsavelItemStateChanged

    private void boxResponsavel1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_boxResponsavel1ItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_boxResponsavel1ItemStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JComboBox<String> boxResponsavel;
    public static javax.swing.JComboBox<String> boxResponsavel1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTableP;
    private com.dataplus.swing.PanelShadow panelShadow1;
    public static javax.swing.JTextField txtPesquisaProcesso;
    // End of variables declaration//GEN-END:variables
}
