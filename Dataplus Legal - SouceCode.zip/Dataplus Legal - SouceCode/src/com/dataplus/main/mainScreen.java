package com.dataplus.main;

import connection.connection;
import static com.dataplus.component.Bottom.imageAvatar1;
import static com.dataplus.component.Bottom.jLabel1;
import com.dataplus.component.Menu;
import com.dataplus.event.EventMenuSelected;
import com.dataplus.form.FormHome;
import com.dataplus.form.FormClientes;
import com.dataplus.form.FormContratos;
import com.dataplus.form.FormGraficos;
import com.dataplus.form.FormProcessos;
import com.dataplus.model.ModelMenu;
import com.dataplus.model.modelUser;
import com.dataplus.swing.MenuItem;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import net.miginfocom.swing.MigLayout;
import org.jdesktop.animation.timing.Animator;
import org.jdesktop.animation.timing.TimingTarget;
import org.jdesktop.animation.timing.TimingTargetAdapter;

public class mainScreen extends javax.swing.JFrame {

    private Menu menu = new Menu();

    private MigLayout layout;
    private Animator animator;
    private boolean menuShow;
    connection conexao = new connection();

    public mainScreen() {
        initComponents();
        init();
        setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
        this.setIconImage(new ImageIcon(getClass().getResource("/com/raven/icon/desktopIcon.png")).getImage());

        menu.setEvent(new EventMenuSelected() {
            @Override
            public void selected(int index) {
                showForm(new FormHome());

            }
        });
        
        menu.setSelected(0);
    }

    public void setData(modelUser data) {
        imageAvatar1.setIcon(data.getProfile());
        jLabel1.setText(data.getUserName());
        titulo1.setText("Olá, " + data.getUserName() + ". Aqui esta um resumo para voce.");
    }

    private void init() {
        layout = new MigLayout("fill", "0[]10[]5", "0[fill]0");
        body.setLayout(layout);

        menu.addEventLogout(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (JOptionPane.showConfirmDialog(rootPane, "Tem certeza que deseja sair?") == JOptionPane.YES_OPTION) {
                    try {
                        System.exit(1);

                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(rootPane,
                                e.getMessage(),
                                "ERRO",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        menu.addEventMenu(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (!animator.isRunning()) {
                    animator.start();
                }
            }
        });
        menu.setEvent(new EventMenuSelected() {
            @Override
            public void selected(int index) {
                if (index == 0) {
                    showForm(new FormHome());
                    descricao.setText("Aqui está um resumo para voce.");

                } else if (index == 1) {
                    showForm(new FormClientes());
                    descricao.setText("Esses são os seus clientes.");

                } else if (index == 2) {
                    showForm(new FormContratos());
                    descricao.setText("Aqui estão os contratos fechados.");
                } else if (index == 3) {
                    showForm(new FormProcessos());
                    descricao.setText("Estes são os processos em andamento");
                } else if (index == 4) {
                    showForm(new FormGraficos());
                    descricao.setText("Informações do sistema");
                }
            }
        });
        menu.addMenu(new ModelMenu("Home", new ImageIcon(getClass().getResource("/com/raven/icon/Home3.png"))));
        menu.addMenu(new ModelMenu("Clientes", new ImageIcon(getClass().getResource("/com/raven/icon/Profile.png"))));
        menu.addMenu(new ModelMenu("Contratos", new ImageIcon(getClass().getResource("/com/raven/icon/Paper.png"))));
        menu.addMenu(new ModelMenu("Processos...", new ImageIcon(getClass().getResource("/com/raven/icon/Work.png"))));
        menu.addMenu(new ModelMenu("Em Breve...", new ImageIcon(getClass().getResource("/com/raven/icon/MoreCircle.png"))));
        body.add(menu, "w 80!");

        TimingTarget target = new TimingTargetAdapter() {
            @Override
            public void timingEvent(float fraction) {
                double width;
                if (menuShow) {
                    width = 80 + (150 * (1f - fraction));
                    menu.setAlpha(1f - fraction);
                } else {
                    width = 80 + (150 * fraction);
                    menu.setAlpha(fraction);
                }
                layout.setComponentConstraints(menu, "w " + width + "!");
                body.revalidate();

            }

            @Override
            public void end() {
                menuShow = !menuShow;
            }
        };
        animator = new Animator(400, target);
        animator.setResolution(0);
        animator.setAcceleration(0.5f);
        animator.setDeceleration(0.5f);
        showForm(new FormHome());
    }

    public void showForm(Component com) {
        main.removeAll();
        main.add(com);
        main.repaint();
        main.revalidate();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        body = new javax.swing.JPanel();
        main = new javax.swing.JPanel();
        descricao = new javax.swing.JLabel();
        titulo1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Dataplus Legal Management 3.0");
        setBackground(new java.awt.Color(244, 246, 255));
        setMinimumSize(new java.awt.Dimension(800, 800));

        jPanel1.setBackground(new java.awt.Color(245, 245, 253));

        body.setBackground(new java.awt.Color(244, 246, 255));

        javax.swing.GroupLayout bodyLayout = new javax.swing.GroupLayout(body);
        body.setLayout(bodyLayout);
        bodyLayout.setHorizontalGroup(
            bodyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 39, Short.MAX_VALUE)
        );
        bodyLayout.setVerticalGroup(
            bodyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        main.setOpaque(false);
        main.setLayout(new java.awt.BorderLayout());

        descricao.setFont(new java.awt.Font(".AppleSystemUIFont", 1, 18)); // NOI18N
        descricao.setForeground(new java.awt.Color(102, 102, 102));
        descricao.setText("Aqui está um resumo para voce.");

        titulo1.setFont(new java.awt.Font(".AppleSystemUIFont", 1, 26)); // NOI18N
        titulo1.setForeground(new java.awt.Color(51, 51, 51));
        titulo1.setText("Olá Rafael, bem vindo");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(body, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(main, javax.swing.GroupLayout.DEFAULT_SIZE, 753, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(descricao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(titulo1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(body, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(titulo1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(descricao)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(main, javax.swing.GroupLayout.DEFAULT_SIZE, 383, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(mainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(mainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(mainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(mainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new mainScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel body;
    private javax.swing.JLabel descricao;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JPanel main;
    private javax.swing.JLabel titulo1;
    // End of variables declaration//GEN-END:variables
}
