/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dataplus.model;

import com.dataplus.form.FormEditarProcessos;
import static com.dataplus.form.FormEditarProcessos.txtProcesso;
import connection.connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import jdk.internal.foreign.CABI;

/**
 *
 * @author rafaelcorrea
 */
public class modelCalendarioDAO {

    public void create(modelCalendario ca) {
        Connection con = connection.getConnection();
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO calendario (idcalendario, iddata, data, descricao) VALUES(null,?,?,?)");
            stmt.setInt(1, ca.getIdData());
            stmt.setString(2, ca.getData());
            stmt.setString(3, ca.getDescricao());
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir: " + ex);
        } finally {
            connection.closeConnection(con, stmt);
        }
    }

    public List<modelCalendario> read() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelCalendario> datas = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM calendario");
            rs = stmt.executeQuery();

            while (rs.next()) {

                modelCalendario ca = new modelCalendario();
                ca.setIdData(rs.getInt(2));
                ca.setData(rs.getString(3));
                ca.setDescricao(rs.getString(4));

                datas.add(ca);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            connection.closeConnection(con, stmt, rs);
        }
        return datas;

    }

    public List<modelCalendario> readCustom() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelCalendario> datas = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM calendario WHERE iddata = ?");
            stmt.setInt(1, Integer.parseInt(txtProcesso.getText()));
            rs = stmt.executeQuery();

            while (rs.next()) {
                
                modelCalendario ca = new modelCalendario();
                ca.setData(rs.getString(3));
                ca.setDescricao(rs.getString(4));
                datas.add(ca);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            connection.closeConnection(con, stmt, rs);
        }
        return datas;

    }

    public void delete(modelCalendario ca) {

        Connection con = connection.getConnection();

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM calendario WHERE iddata = ?");
            stmt.setInt(1, ca.getIdData());

            stmt.executeUpdate();
            read();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            connection.closeConnection(con, stmt);
        }

    }

}
