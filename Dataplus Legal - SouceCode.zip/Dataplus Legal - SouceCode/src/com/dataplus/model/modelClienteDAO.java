package com.dataplus.model;

import com.dataplus.form.FormClientes;
import com.dataplus.form.FormProcessos;
import connection.connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author rafaelcorrea
 */
public class modelClienteDAO {

    public void create(modelCliente c) {
        Connection con = connection.getConnection();
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO cliente (idcliente,nome,cidade,uf,logradouro,email,telefone,medicamentos)VALUES(null,?,?,?,?,?,?,?)");
            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getCidade());
            stmt.setString(3, c.getUf());
            stmt.setString(4, c.getLogradouro());
            stmt.setString(5, c.getEmail());
            stmt.setString(6, c.getTelefone());
            stmt.setString(7, c.getMedicamentos());

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir: " + ex);
        } finally {
            connection.closeConnection(con, stmt);
        }
    }

    public List<modelCliente> read() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelCliente> clientes = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM cliente order by nome");
            rs = stmt.executeQuery();

            while (rs.next()) {

                modelCliente c = new modelCliente();

                c.setIdcliente(rs.getInt(1));
                c.setNome(rs.getString(2));
                c.setCidade(rs.getString(3));
                c.setUf(rs.getString(4));
                c.setLogradouro(rs.getString(5));
                c.setEmail(rs.getString(6));
                c.setTelefone(rs.getString(7));
                c.setMedicamentos(rs.getString(8));
                clientes.add(c);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
            connection.closeConnection(con, stmt, rs);
        }
        return clientes;

    }
    
    public void delete(modelCliente c) {

        Connection con = connection.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM cliente WHERE idcliente = ?");
            stmt.setInt(1, c.getIdcliente());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            connection.closeConnection(con, stmt);
        }

    }
    
    public List<modelCliente> search() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelCliente> clientes = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM cliente where nome like '" + FormClientes.jTextField1.getText() + "%' ORDER BY nome");
            rs = stmt.executeQuery();

            while (rs.next()) {

                modelCliente c = new modelCliente();

                c.setIdcliente(rs.getInt(1));
                c.setNome(rs.getString(2));
                c.setCidade(rs.getString(3));
                c.setUf(rs.getString(4));
                c.setLogradouro(rs.getString(5));
                c.setEmail(rs.getString(6));
                c.setTelefone(rs.getString(7));
                c.setMedicamentos(rs.getString(8));
                clientes.add(c);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
            connection.closeConnection(con, stmt, rs);
        }
        return clientes;

    }
    
    public List<modelCliente> searchComboC() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelCliente> clientes = new ArrayList<>();

        try {
            String r = FormClientes.comboUF.getSelectedItem().toString();
            String SQL = null;
            
            if (r == "-") {
                SQL = "SELECT * FROM cliente";
            } else if (r != "-") {
                SQL = "SELECT * FROM cliente where uf= '" + r + "'";
            }

            stmt = con.prepareStatement(SQL);

            rs = stmt.executeQuery();

            while (rs.next()) {

                modelCliente c = new modelCliente();

                c.setIdcliente(rs.getInt(1));
                c.setNome(rs.getString(2));
                c.setCidade(rs.getString(3));
                c.setUf(rs.getString(4));
                c.setLogradouro(rs.getString(5));
                c.setEmail(rs.getString(6));
                c.setTelefone(rs.getString(7));
                c.setMedicamentos(rs.getString(8));
                clientes.add(c);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            connection.closeConnection(con, stmt, rs);
        }
        return clientes;

    }
    
        public List<modelCliente> readUF() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelCliente> clientes = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT distinct uf from cliente");
            rs = stmt.executeQuery();

            while (rs.next()) {

                modelCliente c = new modelCliente();

                c.setUf(rs.getString("uf"));
                clientes.add(c);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
            connection.closeConnection(con, stmt, rs);
        }
        return clientes;

    }

    
    
}
