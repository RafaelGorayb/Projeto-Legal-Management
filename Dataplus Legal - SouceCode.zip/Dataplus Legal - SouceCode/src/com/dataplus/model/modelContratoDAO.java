package com.dataplus.model;

import com.dataplus.form.FormContratos;
import com.dataplus.form.FormProcessos;
import connection.connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author rafaelcorrea
 */
public class modelContratoDAO {

    public void create(modelContrato ct) {
        Connection con = connection.getConnection();
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO contrato (idcontrato,data,metodoPagamento,valor,parcelas,observacoes,cliente_idcliente)VALUES(null,?,?,?,?,?,?)");
            stmt.setString(1, ct.getData());
            stmt.setString(2, ct.getMetodoPagamento());
            stmt.setInt(3, ct.getValor());
            stmt.setInt(4, ct.getParcelas());
            stmt.setString(5, ct.getObservacoes());
            stmt.setInt(6, ct.getCliente_idcliente());

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir: " + ex);
        } finally {
            connection.closeConnection(con, stmt);
        }
    }

    public List<modelContrato> read() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelContrato> contratos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("select * from contrato \n"
                    + "inner join cliente\n"
                    + "on contrato.cliente_idcliente = cliente.idcliente");
            rs = stmt.executeQuery();

            while (rs.next()) {

                modelContrato ct = new modelContrato();

                ct.setIdcontrato(rs.getInt("idcontrato"));
                ct.setData(String.valueOf(rs.getDate("data")));
                ct.setMetodoPagamento(rs.getString("metodoPagamento"));
                ct.setValor(rs.getInt("valor"));
                ct.setParcelas(rs.getInt("parcelas"));
                ct.setObservacoes(rs.getString("observacoes"));
                ct.setCliente_idcliente(rs.getInt("cliente_idcliente"));
                ct.setNomeCliente(rs.getString("nome"));

                contratos.add(ct);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            connection.closeConnection(con, stmt, rs);
        }
        return contratos;

    }

    public void delete(modelContrato ct) {

        Connection con = connection.getConnection();

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM contrato WHERE idcontrato = ?");
            stmt.setInt(1, ct.getIdcontrato());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            connection.closeConnection(con, stmt);
        }

    }

    public List<modelContrato> searchCt() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelContrato> contratos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("select * from contrato \n" +
                                        "inner join cliente\n" +
                                        "on contrato.cliente_idcliente = cliente.idcliente\n" +
                                        "and cliente.nome like '" + FormContratos.txtPesquisaContrato.getText() + "%' order by nome ");
            rs = stmt.executeQuery();

            while (rs.next()) {

                modelContrato ct = new modelContrato();

                ct.setIdcontrato(rs.getInt("idcontrato"));
                ct.setData(String.valueOf(rs.getDate("data")));
                ct.setMetodoPagamento(rs.getString("metodoPagamento"));
                ct.setValor(rs.getInt("valor"));
                ct.setParcelas(rs.getInt("parcelas"));
                ct.setObservacoes(rs.getString("observacoes"));
                ct.setCliente_idcliente(rs.getInt("cliente_idcliente"));
                ct.setNomeCliente(rs.getString("nome"));

                contratos.add(ct);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            connection.closeConnection(con, stmt, rs);
        }
        return contratos;

    }

}
