
package com.dataplus.model;

import java.util.Date;

/**
 *
 * @author rafaelcorrea
 */
public class modelProcesso {

    public int getIdprocesso() {
        return idprocesso;
    }

    public void setIdprocesso(int idprocesso) {
        this.idprocesso = idprocesso;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getReu() {
        return reu;
    }

    public void setReu(String reu) {
        this.reu = reu;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }

    public String getJusticaGratuita() {
        return justicaGratuita;
    }

    public void setJusticaGratuita(String justicaGratuita) {
        this.justicaGratuita = justicaGratuita;
    }

    public String getDanosMorais() {
        return danosMorais;
    }

    public void setDanosMorais(String danosMorais) {
        this.danosMorais = danosMorais;
    }

    public int getValorCausa() {
        return valorCausa;
    }

    public void setValorCausa(int valorCausa) {
        this.valorCausa = valorCausa;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCliente_idcliente() {
        return cliente_idcliente;
    }

    public void setCliente_idcliente(int cliente_idcliente) {
        this.cliente_idcliente = cliente_idcliente;
    }



 

    private int idprocesso;
    private String titulo;
    private String reu;
    private String autor;
    private String responsavel;
    private String justicaGratuita;
    private String danosMorais;
    private int valorCausa;
    private String observacoes;
    private String status;
    private int cliente_idcliente;
    
    
}
