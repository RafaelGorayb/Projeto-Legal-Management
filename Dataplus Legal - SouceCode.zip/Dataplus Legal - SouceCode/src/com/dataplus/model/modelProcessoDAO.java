/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dataplus.model;

import com.dataplus.form.FormProcessos;
import connection.connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author rafaelcorrea
 */
public class modelProcessoDAO {

    public void create(modelProcesso p) {
        Connection con = connection.getConnection();
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO processo (idprocesso,reu,status,cliente_idcliente,responsavel,Autor,justicaGratuita,danosMorais,valorDaCausa,observacoes)VALUES(?,?,?,?,?,?,?,?,?,?)");
            stmt.setInt(1, p.getIdprocesso());
            stmt.setString(2, p.getReu());
            stmt.setString(3, p.getStatus());
            stmt.setInt(4, p.getCliente_idcliente());
            stmt.setString(5, p.getResponsavel());
            stmt.setString(6, p.getAutor());
            stmt.setString(7, p.getJusticaGratuita());
            stmt.setString(8, p.getDanosMorais());
            stmt.setInt(9, p.getValorCausa());
            stmt.setString(10, p.getObservacoes());
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir: " + ex);
        } finally {
            connection.closeConnection(con, stmt);
        }
    }

    public List<modelProcesso> read() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelProcesso> processos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM processo");
            rs = stmt.executeQuery();

            while (rs.next()) {

                modelProcesso p = new modelProcesso();

                p.setIdprocesso(rs.getInt("idprocesso"));
                p.setReu(rs.getString("reu"));
                p.setStatus(rs.getString("status"));
                p.setResponsavel(rs.getString("responsavel"));
                p.setAutor(rs.getString("Autor"));
                p.setCliente_idcliente(rs.getInt("cliente_idcliente"));
                p.setJusticaGratuita(rs.getString("justicaGratuita"));
                p.setDanosMorais(rs.getString("danosMorais"));
                p.setValorCausa(rs.getInt("valorDaCausa"));
                p.setObservacoes(rs.getString("observacoes"));

                processos.add(p);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            connection.closeConnection(con, stmt, rs);
        }
        return processos;

    }

    public List<modelProcesso> searchField() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelProcesso> processos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM processo where idprocesso like '" + FormProcessos.txtPesquisaProcesso.getText() + "%' ORDER BY idprocesso");
            rs = stmt.executeQuery();

            while (rs.next()) {

                modelProcesso p = new modelProcesso();

                p.setIdprocesso(rs.getInt("idprocesso"));
                p.setReu(rs.getString("reu"));
                p.setStatus(rs.getString("status"));
                p.setResponsavel(rs.getString("responsavel"));
                p.setAutor(rs.getString("Autor"));
                p.setCliente_idcliente(rs.getInt("cliente_idcliente"));
                p.setJusticaGratuita(rs.getString("justicaGratuita"));
                p.setDanosMorais(rs.getString("danosMorais"));
                p.setValorCausa(rs.getInt("valorDaCausa"));
                p.setObservacoes(rs.getString("observacoes"));

                processos.add(p);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            connection.closeConnection(con, stmt, rs);
        }
        return processos;

    }

    public List<modelProcesso> searchCombo() {

        Connection con = connection.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<modelProcesso> processos = new ArrayList<>();

        try {
            String r = FormProcessos.boxResponsavel.getSelectedItem().toString();
            String SQL = null;
            
            if (r == "-") {
                SQL = "SELECT * FROM processo";
            } else if (r != "-") {
                SQL = "SELECT * FROM processo where responsavel= '" + r + "'";
            }

            stmt = con.prepareStatement(SQL);

            rs = stmt.executeQuery();

            while (rs.next()) {

                modelProcesso p = new modelProcesso();

                p.setIdprocesso(rs.getInt("idprocesso"));
                p.setReu(rs.getString("reu"));
                p.setStatus(rs.getString("status"));
                p.setResponsavel(rs.getString("responsavel"));
                p.setAutor(rs.getString("Autor"));
                p.setCliente_idcliente(rs.getInt("cliente_idcliente"));
                p.setJusticaGratuita(rs.getString("justicaGratuita"));
                p.setDanosMorais(rs.getString("danosMorais"));
                p.setValorCausa(rs.getInt("valorDaCausa"));
                p.setObservacoes(rs.getString("observacoes"));

                processos.add(p);
            }

        } catch (SQLException ex) {
            Logger.getLogger(modelClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            connection.closeConnection(con, stmt, rs);
        }
        return processos;

    }

    public void delete(modelProcesso p) {

        Connection con = connection.getConnection();

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM processo WHERE idprocesso = ?");
            stmt.setInt(1, p.getIdprocesso());

            stmt.executeUpdate();
            read();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            connection.closeConnection(con, stmt);
        }

    }

}
